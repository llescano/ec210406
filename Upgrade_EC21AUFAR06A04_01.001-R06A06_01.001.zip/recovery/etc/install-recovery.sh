#!/system/bin/sh
if ! applypatch -c MTD:recovery:5920768:b333b39b5973b74edd199bc4d69691b5d3d438db; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:5920768:b333b39b5973b74edd199bc4d69691b5d3d438db MTD:recovery b333b39b5973b74edd199bc4d69691b5d3d438db 5920768 b333b39b5973b74edd199bc4d69691b5d3d438db:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
